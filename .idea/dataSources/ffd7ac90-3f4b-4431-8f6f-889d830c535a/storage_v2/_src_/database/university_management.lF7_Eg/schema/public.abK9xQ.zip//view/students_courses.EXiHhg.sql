create view students_courses (id, first_name, last_name, age, gender, email, phone_number, national_id) as
SELECT student.id,
       student.first_name,
       student.last_name,
       student.age,
       student.gender,
       student.email,
       student.phone_number,
       student.national_id
FROM student
         JOIN student_course ON student.id = student_course.student_id;

alter table students_courses
    owner to postgres;

