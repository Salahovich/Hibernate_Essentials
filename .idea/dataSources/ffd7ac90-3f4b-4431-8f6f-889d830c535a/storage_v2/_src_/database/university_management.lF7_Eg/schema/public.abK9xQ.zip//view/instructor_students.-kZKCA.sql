create view instructor_students
            ("Full Name", id, first_name, last_name, age, gender, email, phone_number, national_id) as
SELECT (instructor.first_name::text || ','::text) || instructor.last_name::text AS "Full Name",
       student.id,
       student.first_name,
       student.last_name,
       student.age,
       student.gender,
       student.email,
       student.phone_number,
       student.national_id
FROM instructor
         JOIN course ON course.instructor_id = instructor.id
         JOIN student_course ON student_course.course_id = course.id
         JOIN student ON student.id = student_course.student_id;

alter table instructor_students
    owner to postgres;

