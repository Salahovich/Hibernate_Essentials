create view all_courses2 (id, name, start_date, end_date, course_level, is_started, instructor_id) as
SELECT course.id,
       course.name,
       course.start_date,
       course.end_date,
       course.course_level,
       course.is_started,
       course.instructor_id
FROM course;

alter table all_courses2
    owner to postgres;

