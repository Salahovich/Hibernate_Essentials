create materialized view all_courses as
SELECT course.id,
       course.name,
       course.start_date,
       course.end_date,
       course.course_level,
       course.is_started,
       course.instructor_id
FROM course;

alter materialized view all_courses owner to postgres;

